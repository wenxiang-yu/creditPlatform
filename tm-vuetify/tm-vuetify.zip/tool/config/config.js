/**
 * 创建时间：2021年7月2日11:24:23
 * 作者：tmzdy
 */
let ver = '2.0.0';
export default {
	v: ver,
	version: ver,
	V:ver,
	ver:ver
}